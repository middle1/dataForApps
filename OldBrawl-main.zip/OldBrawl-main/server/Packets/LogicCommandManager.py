from Packets.Commands.Client.LogicGatchaCommand import LogicGatchaCommand
from Packets.Commands.Client.LogicSelectSkinCommand import LogicSelectSkinCommand

commands = {
    500: LogicGatchaCommand,
    506: LogicSelectSkinCommand
}
